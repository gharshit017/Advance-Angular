import { Component } from '@angular/core';

@Component({
  selector: 'app-my-hooks',
  templateUrl: './my-hooks.component.html',
  styleUrls: ['./my-hooks.component.scss']
})
export class MyHooksComponent {
  amount =300
  channelNAme = "CodeWithOP"
  marks = 0.89
  date = new Date()
  name =  "Om Prakash"
}
